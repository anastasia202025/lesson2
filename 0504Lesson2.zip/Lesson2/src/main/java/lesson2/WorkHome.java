package lesson2;

import com.sun.xml.internal.fastinfoset.algorithm.BuiltInEncodingAlgorithm;

public class WorkHome {
    public static void main(String[] args) {

    // System.out.println(within10and20(int a;int b)); - передаем уже конкретные значения, т.е. в методе мы как бы задали образец и он уже знает, что ему придут int

    System.out.println(within10and20(1, 19)); // 1+19 = 20 => true
    isPositiveOrNegative(-2); // -2 отрицательное
    System.out.println(isNegative(8));
    printWordNTimes("Абвгд", 4);
}


        public static boolean within10and20(int a, int b) {
            // int a = 15; Не нужно, параметры передаются когда вызываем метод, тут просто образец поведения
            // int b=7;
            int sum = a + b;
            if (sum >= 10 && sum <= 20) { // в условии "от 10 до 20 (включительно)", значит  >= и <=
                return true;
            } else {
                return false;
            }
        }

        public static void isPositiveOrNegative(int x) {
            if (x >= 0) {
                // int x = 10; убираем
                System.out.println("Число " + x + " положительное");
            } else {
                System.out.println("Число " + x + " отрицательное");
            }
        }

        public static boolean isNegative(int q) {
            // int q = -7; убираем
            if (q < 0) {
                return true;
            } else {
                return false;
            }
        }

        public static void printWordNTimes(String word, int times) {
            for (int i = 0; i < times; i++) {
                System.out.println(word);
            }
        }}





